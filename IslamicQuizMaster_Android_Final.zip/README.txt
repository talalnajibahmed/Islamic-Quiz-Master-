ISLAMIC QUIZ MASTER — ANDROID PROJECT

Version: 1.0
Package: com.islamicquizmaster.app

Included:
- 3 levels, 10 questions each
- Level progression/unlocking
- 100 starting coins
- +10 correct / -5 wrong (never below 0)
- Completion bonuses: 50 / 75 / 100
- Offline local quiz content
- Soft visual Islamic theme
- No copyrighted naat recording or lyrics included

BUILD:
Open this folder in Android Studio, let Gradle sync, then Build > Generate Signed Bundle / APK.
For Google Play, choose Android App Bundle (AAB) and create/use a signing key.

IMPORTANT:
The ZIP is the project source, not a Play Store-approved release. Before publishing, test on real Android devices, complete Play Console app-content declarations, privacy information as applicable, store listing, and required testing/review.
